from funcs import *
valid_url = False
valid_user_data = False
restart_script = True

while valid_url == False and valid_user_data == False and restart_script == True:
    # Запрос ввода ссылки, имени фильтра и значений фильтра
    print("", end="\n\n")
    cat_url = input("Введите ссылку: ")
    filter_name = input("Введите имя фильтра: ")
    filter_value = input("Введите значения фильтра: ")

    print("", end="\n\n")

    # Проверка валидности URL
    if validators.url(cat_url):
        valid_url = True
        print("Вы ввели следующие данные:")
        print("Ссылка: ", cat_url)
        print("Имя фильтра: ", filter_name)
        print("Значение фильтра: ", filter_value)

        print("", end="\n\n")

        # Запрос у пользователя, уверен ли он
        response = input("Вы уверены? (y/n): ")

        if response.lower() != "y":
            # Очистить экран и начать ввод данных заново
            os.system('cls' if os.name == 'nt' else 'clear')
            valid_user_data = False
        else:
            valid_user_data = True

    # если URL невалидний
    else:
        valid_url = False
        print("Введенная ссылка не является валидной. Пожалуйста, введите валидную ссылку.", end="\n\n")
        print("Нажмите Enter для продолжения...")
        break

    print("", end="\n\n")

    while restart_script == True and valid_user_data == True and valid_url == True:
        if parser(cat_url, filter_name, filter_value) == True:
            valid_url = False
            valid_user_data = False
            restart_script = True

    # Запрос у пользователя, уверен ли он
    response = input("Вам повторить? (y/n): ")

    if response.lower() != "y":
        # Очистить экран и начать ввод данных заново
        os.system('cls' if os.name == 'nt' else 'clear')
        restart_script = False
    else:
        # Очистить экран и начать ввод данных заново
        os.system('cls' if os.name == 'nt' else 'clear')
        restart_script = True
        valid_url = False
        valid_user_data = False

        print("", end="\n\n")


input("Скрипт остановлен. Нажмите Enter для продолжения")


