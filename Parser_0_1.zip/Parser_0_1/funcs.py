import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import requests
import mysql.connector
import validators
import os

def parser(cat_url, filter_name, filter_value):

	db_table_name = cat_url.split('/')[5]
	db_table_name = db_table_name.lower().replace('-','_')
	db_table_name = re.sub(r"[^a-z,_]", "", db_table_name)

	# данные для подключения к базе данных
	db_host = ''
	db_user = ''
	db_password = ''
	db_name = ''

	# Создаем соединение с базой данных и курсор
	connection = mysql.connector.connect(
		host=db_host,
		user=db_user,
		password=db_password,
		database=db_name
	)

	if connection.is_connected():

		print("Успешное подключение к базе данных")

	# URL веб-страницы
	url = cat_url

	# Загружаем веб-страницу
	response = requests.get(url)

	# Проверяем, что запрос успешен
	if response.status_code == 200:
		# Получаем HTML-код веб-страницы
		page_source = response.text

		# Создаем объект BeautifulSoup для разбора HTML-кода
		soup = BeautifulSoup(page_source, 'html.parser')

	# По умолчанию считаем что страница 1 шт
	brand_last_page = 1

	# Ищем все теги <a> с классом "paggination__page"
	a_tags = soup.find("div", class_='nav-list').find_all("li")

	if a_tags:

		# Устанавливаем значение по умолчанию если пагинация отсутствует
		brand_last_page = int(a_tags[-2].text)

	else:
		brand_last_page = 1



	i = 0

	for x in range(brand_last_page):

		# формируем текущий URL для парсинга
		url = cat_url + "?PAGEN_1=" + str(x+1)
		print(url)

		# Отправляем GET-запрос на страницу по текущему URL-адресу
		response = requests.get(url)

		if response.status_code == 200:
			# Создаем объект BeautifulSoup для разбора страницы
			page_soup = BeautifulSoup(response.text, 'html.parser')

			# Ищем все теги <div> с классом "catalog-item-2"
			li_tags = page_soup.find_all("div", class_='catalog-item-2')

			# Перебираем все найденные элементы <li>
			for li_tag in li_tags:
				a_tag_models = li_tag.find('a', class_='catalog-item-2-card__title')
				p_tags_categories = li_tag.find('div', class_='catalog-item-2-card__code')
				a_tag_site_produсt_id = li_tag.find('div', class_='catalog-item-2-card__code')

				# Создаем пустой список для товаров
				product_list = []

				for a_tag_models, p_tags_categories, a_tag_site_produсt_id in zip(a_tag_models, p_tags_categories, a_tag_site_produсt_id):
					model = a_tag_models.get_text(strip=True)
					article = p_tags_categories.get_text(strip=True).replace("Код товару: ", "")
					produсt_id = a_tag_site_produсt_id.get_text(strip=True)
					
					# Удаляем "Артикул:" из начала строки
					article = article.replace("Код товару: ", "")

					# Создаем словарь для товара
					product_dict = {
						'sku': article,
						'site_produсt_id': produсt_id,
						'name': model,
					}
					product_list.append(product_dict)

					i += 1

					print ("#",i,": ", product_dict)
		else:
			print ("Error response: ", response.status_code)
			



	# Выполнение SQL-запросов
	cursor = connection.cursor()

	# если имя и значение фильтра НЕ пустое значит мы собираем фильтра
	if filter_name != "" and filter_value != "":

		print("now get filters")

		# проверяем существование столбца фильтра
		sql_query = "SHOW COLUMNS from cat_" + db_table_name + " LIKE '" + filter_name + "'"
		cursor.execute(sql_query)
		cursor.fetchall()
		connection.commit()

		# если ответ от БД дал НОЛЬ строк значит колонки НЕТ
		if cursor.rowcount == 0:
			# создаем поле в БД для фильтра
			alter_table_query = "ALTER TABLE cat_" + db_table_name + " ADD "+filter_name+" VARCHAR(255) NOT NULL"
			cursor.execute(alter_table_query)
			cursor.fetchall()
			connection.commit()


		# Вставляем данные в таблицу
		for product in product_list:

			# sql_query = "UPDATE `cat_dvr` SET `typ_reestratora`='NVR' WHERE `site_produсt_id` LIKE 'DHI-NVR2108-I2'"

			update_query = "UPDATE cat_%s SET %s = '%s' WHERE site_produсt_id LIKE '%s' " % ( db_table_name, filter_name, filter_value, product['site_produсt_id'] )
			print (update_query)
			cursor.execute(update_query)
			connection.commit()



	# если имя и значение фильтра ПУСТЫЕ значит мы создаем новую таблицу и собираем ВСЕ товары
	else:

		# Создаем таблицу
		sql_query = "CREATE TABLE IF NOT EXISTS cat_%s (id INT AUTO_INCREMENT PRIMARY KEY, sku VARCHAR(255), name VARCHAR(255), site_produсt_id VARCHAR(255) ) " % ( db_table_name )

		cursor.execute(sql_query)
		
		# Сохраняем изменения в базе данных
		connection.commit()

		# Вставляем данные в таблицу
		for product in product_list:

			insert_query = "INSERT INTO cat_" + db_table_name + "  (sku, name, site_produсt_id) VALUES (%s, %s, %s)"
			cursor.execute(insert_query, (product['sku'], product['name'], product['site_produсt_id']))
			connection.commit()

	# Закрываем курсор и соединение
	cursor.close()
	connection.close()